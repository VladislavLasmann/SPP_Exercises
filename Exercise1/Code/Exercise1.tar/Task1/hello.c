#include <stdio.h>


int main(){
    printf("Hallo Welt!\n");
}