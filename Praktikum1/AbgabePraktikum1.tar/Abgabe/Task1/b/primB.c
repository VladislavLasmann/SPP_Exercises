/**
 * Gruppe: 122
 * Konstantin Müller (2327697) 
 * Robin Ferrari 	 (2585277) 
 * Vladislav Lasmann (2593078)
 */
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<omp.h>
#include"primB.h"

// is called when program is not started with positive int
int throwError() {
    printf("Please pass a positive Integer N and a blocksize for omp\n");
    return 1;
}


// gives back a array where Array[i] == 0 means i is prim.
unsigned char* isPrim(unsigned char* theArray, long n, long blockSize) {
    // this loop will execute all the inner loop for each i
    #pragma omp parallel for schedule(static, blockSize)
    for (int i = 0; i < n; i++) {
        // initialize [i]
        theArray[i] = 0;
        // this loop will try to divide i with each number between 1 and the root of i  if the rest 
        // is allways not zero i is only divisible by 1 and i therfore i is prim
        int z = sqrt(i);
        for (int j = 2; j <= z; j++) {
            // if true not a prim
            if (i % j == 0) {
                theArray[i] = 1;
                break;
            }
        }
    }

    return theArray;
}

// prints index of array when array[i] == 0
void printPrims(unsigned char* theArray, long n) {
    // refering to wikipedia the numbers 0 and 1 are not prime
    for (long i = 2; i < n; i++) {
       if (theArray[i] == 0) 
          printf("%ld\n", i);
    }
} 

// Checks if a number is Prim. Pass a positive integer N as argument and the program is given back
// an array for all numbers from 0 to N and tells if it is prim or not

int main(int argc, char *argv[]) {
    // lets get the start time
    double startTime = omp_get_wtime();
    
    // here we check if a integer was passed (first argument is program name)
    if (argc != 3) 
        return throwError();

    // now lets convert the string to a long int with atol()
    long n = atol(argv[1]);

    // now lets check that n is positive
    if (n < 1)
        return throwError();

    // now get blockSize
    long bS = atol(argv[2]);
    
    // lets create the Array A
    // we want check if n is prim so we just make n+1
    n += 1;
    unsigned char* theArray = (unsigned char*) malloc(sizeof(char) * n);

    printPrims(isPrim(theArray, n, bS), n);

    free(theArray);
    //print the time
    double finalTime = omp_get_wtime() - startTime;
    printf("Program finished and checked %ld numbers in %g seconds with a BlockSize of %ld\n",
            (n - 1), // -1 because we incremented n for correct array size
            finalTime,
            bS
            );

    return 0;
}
