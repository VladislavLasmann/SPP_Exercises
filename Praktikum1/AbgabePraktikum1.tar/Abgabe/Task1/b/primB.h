/**
 * Gruppe: 122
 * Konstantin Müller (2327697) 
 * Robin Ferrari 	 (2585277) 
 * Vladislav Lasmann (2593078)
 */
#ifndef PRIMB_H
#define PRIMB_H

int throwError();
unsigned char* isPrim(unsigned char* theArray, long n, long blockSize);
void printPrims(unsigned char* theArray, long n);

#endif // PRIMB_H