## This bash script runs all job-scripts for this task and lets 
## save the outputs in the OUTPUT-folder

## first compile the programm
make

### the jobscript got passed two parameters:
###     first one:  blocksize       ($1)
###     second one: thread-number   ($2)

## blocksize: 1
sbatch jobScript.sh 1 2
sbatch jobScript.sh 1 4
sbatch jobScript.sh 1 8
sbatch jobScript.sh 1 16

## blocksize: 10
sbatch jobScript.sh 10 2
sbatch jobScript.sh 10 4
sbatch jobScript.sh 10 8 
sbatch jobScript.sh 10 16

## blocksize: 100
sbatch jobScript.sh 100 2
sbatch jobScript.sh 100 4 
sbatch jobScript.sh 100 8 
sbatch jobScript.sh 100 16

## blocksize: 1000
sbatch jobScript.sh 1000 2
sbatch jobScript.sh 1000 4
sbatch jobScript.sh 1000 8
sbatch jobScript.sh 1000 16

## blocksize: 10000
sbatch jobScript.sh 10000 2 
sbatch jobScript.sh 10000 4
sbatch jobScript.sh 10000 8
sbatch jobScript.sh 10000 16

## blocksize: 100000
sbatch jobScript.sh 100000 2
sbatch jobScript.sh 100000 4
sbatch jobScript.sh 100000 8
sbatch jobScript.sh 100000 16

## blocksize: 1000000
sbatch jobScript.sh 1000000 2
sbatch jobScript.sh 1000000 4
sbatch jobScript.sh 1000000 8
sbatch jobScript.sh 1000000 16