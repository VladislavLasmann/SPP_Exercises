/**
 * Gruppe: 122
 * Konstantin Müller (2327697) 
 * Robin Ferrari 	 (2585277) 
 * Vladislav Lasmann (2593078)
 */
#ifndef PRIMD_H
#define PRIMD_H

int throwError();
unsigned char* isPrim(unsigned char* theArray, long n, long blockSize, long threadNum);
void printPrims(unsigned char* theArray, long n);

#endif // PRIMD_H