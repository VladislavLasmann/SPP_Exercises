/**
 * Gruppe: 122
 * Konstantin Müller (2327697) 
 * Robin Ferrari 	 (2585277) 
 * Vladislav Lasmann (2593078)
 */
#ifndef TASK3_H
#define Task3_H

int sum( int* a, unsigned length );
void shift( int* a, unsigned length, unsigned offset );
int hash( int* a, unsigned length );
void init( int* a, unsigned length, int base, int offset );

#endif //MERGE_SORT_H
